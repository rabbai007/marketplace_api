
import java.lang 

######################################################################
#
#  Function:  setAdminRefs 
#  Purpose :  Makes wsadmin commands available to this module.
#
######################################################################

def setAdminRefs(adminTuple):
	global AdminConfig, AdminControl
        global AdminTask, AdminApp
	(AdminConfig, AdminControl, AdminTask, AdminApp) = adminTuple

def preloadCacheCluster(cell, cluster_name):

	preloader = AdminControl.queryNames ( "FDS:name=cachePreloader,*" ) 
	print "INFO : Invoking preload on "+cluster_name+" with "+preloader
	AdminControl.invoke ( preloader , 'startPreload' ) 

def preloadCacheCluster_new(cell, cluster_name, jvm, thisjvm):

        preloader = AdminControl.queryNames ( "FDS:name=cachePreloader,*" ) 
        print "INFO : Invoking preload on "+cluster_name+" with "+preloader+ ", total jvm= "+jvm+", this jvm number= "+thisjvm
        AdminControl.invoke ( preloader , 'startPreload' , jvm , thisjvm ) 

