
import java.lang , time
# Import thread package for using multiple threads
import thread
import sys
from time import strftime

######################################################################
#
#  Function:  setAdminRefs
#  Purpose :  Makes wsadmin commands available to this module.
#
######################################################################

def setAdminRefs(adminTuple):
        global AdminConfig, AdminControl
        global AdminTask, AdminApp
        (AdminConfig, AdminControl, AdminTask, AdminApp) = adminTuple

def formatOutPut(severity,message):
        timestamp = strftime("%Y-%m-%d %H:%M:%S")
        print timestamp+" : "+severity+" : "+message


#
#  Returns 0 for success 1 for still in progress
#
######################################################################
#
#  Function: CheckClusterMembersStartedOnNode
#  Purpose : Checks the start status of members on a node.
#    Returns 0 for success 1 for still in progress
#
######################################################################

def CheckClusterMembersStartedOnNode( cluster_name , node_name ):

   formatOutPut("INFO","Checking start status of cluster members for "+cluster_name+" cluster on node "+node_name)
   cluster_ID=AdminConfig.getid("/ServerCluster:"+cluster_name+"/")

   # Split the list using a java class to determine the OS's line seperator
   cluster_member_list = AdminConfig.list("ClusterMember", cluster_ID).split(java.lang.System.getProperty('line.separator'))

   stop_flag=0

   for cluster_member in cluster_member_list:
   
    cluster_node = AdminConfig.showAttribute(cluster_member,'nodeName')
    server_name  = AdminConfig.showAttribute(cluster_member,'memberName')

    if cluster_node == node_name :
     try :
      serverMBean = AdminControl.completeObjectName("type=Server,process="+server_name+",node="+node_name+",*")
     except :
      time.sleep(30)
      serverMBean = AdminControl.completeObjectName("type=Server,process="+server_name+",node="+node_name+",*")
     
  
     if len(serverMBean) == 0:
      state="STOPPED"
      stop_flag=1

     else:
      state=AdminControl.getAttribute(serverMBean,'state')

     formatOutPut("INFO","Cluster member "+server_name+" on node "+node_name+" is currently "+state )
   
   if stop_flag == 0:
    formatOutPut("INFO","All Cluster members on node "+node_name+" are started") 

   return stop_flag
#
#  Returns 0 for success 1 for still in progress
#
######################################################################
#
# Function: CheckClusterMembersStoppedOnNode
#  Purpose : Checks the stop status of members on a node.
#    Returns 0 for success 1 for still in progress
#
######################################################################

def CheckClusterMembersStoppedOnNode( cluster_name , node_name ):

   formatOutPut("INFO","Checking stop status of cluster members for "+cluster_name+" cluster on node "+node_name)
   
   cluster_ID=AdminConfig.getid("/ServerCluster:"+cluster_name+"/")
   
   # Split the list using a java class to determine the OS's line seperator
   cluster_member_list = AdminConfig.list("ClusterMember", cluster_ID).split(java.lang.System.getProperty('line.separator'))
 

   stop_flag=0

   for cluster_member in cluster_member_list:

    cluster_node = AdminConfig.showAttribute(cluster_member,'nodeName')
    server_name  = AdminConfig.showAttribute(cluster_member,'memberName')

    if cluster_node == node_name :

     try:
      serverMBean = AdminControl.completeObjectName("type=Server,process="+server_name+",node="+node_name+",*")
     except:
      time.sleep(30)
      serverMBean = AdminControl.completeObjectName("type=Server,process="+server_name+",node="+node_name+",*")

     if len(serverMBean) == 0:
      state="STOPPED"

     else:
      state="STARTED"
      stop_flag=1

     formatOutPut("INFO","Cluster member "+server_name+" on node "+node_name+" is currently "+state )
   
   if stop_flag == 0:
    formatOutPut("INFO","All Cluster members on node "+node_name+" are stopped")

   return stop_flag
#
# StopServer
#
def StopServer( node_name, server_name ):

  formatOutPut("INFO","Attempting to Stop " +server_name+" on "+node_name+ ". NOTE: This may take several minutes.")

  serverMBean = AdminControl.completeObjectName("type=Server,process="+server_name+",node="+node_name+",*")

  if len(serverMBean) == 0:
   formatOutPut("INFO",server_name+" on "+node_name+ " is already stopped")
   return 0

  counter = 0

  try:
    AdminControl.invoke(serverMBean , 'stop' )

  except:
    import sys
    except_string1 = sys.exc_type
    except_string2 = sys.exc_value
    timestamp = strftime("%Y-%m-%d %H:%M:%S")

    print timestamp," : WARNING : ",except_string1,except_string2
    #formatOutPut( "ERROR", "wsadmin will now exit with return code 1.  Manual intervention is required" )
    # Exit with error code 1.  The calling script should handle the return code gracefully
    #sys.exit(1)

  formatOutPut("INFO","Stop invoked on server "+server_name+" on "+node_name)

  return 0


def StopServerA( node_name, server_name):

  formatOutPut("INFO","Attempting to Stop " +server_name+" on "+node_name+ ". NOTE: This may take several minutes.")
  
  serverMBean = AdminControl.completeObjectName("type=Server,process="+server_name+",node="+node_name+",*")

  if len(serverMBean) == 0:
   formatOutPut("INFO",server_name+" on "+node_name+ " is already stopped") 
   return 0
  
  counter = 0

  try:
    AdminControl.stopServer(server_name , node_name )

  except:
    import sys
    except_string1 = sys.exc_type
    except_string2 = sys.exc_value  
    timestamp = strftime("%Y-%m-%d %H:%M:%S")
  
    print timestamp," : WARNING : ",except_string1,except_string2
    #formatOutPut( "ERROR", "wsadmin will now exit with return code 1.  Manual intervention is required" )
    # Exit with error code 1.  The calling script should handle the return code gracefully
    #sys.exit(1)

  formatOutPut("INFO","Server "+server_name+" stopped on "+node_name)

  return 0

#
# StopServersOnNode   :  Stops all of the servers on a node
#
def StopServersonNode(node_name):

  formatOutPut("INFO", "Stopping all servers on "+node_name)

  serverMBean = AdminControl.queryNames( "type=Server,processType=ManagedProcess,node="+node_name+",*")

  if len(serverMBean) == 0:
    formatOutPut("INFO", "All Servers on node "+node_name+" are already stopped" )
    return 0

  server_list = serverMBean.split('\n')

  for server in server_list:
    AdminControl.invoke(server,'stop')

  return 0



#
# StartServer : Starts an application server
#

def StartServer( node_name, server_name, mail_from, mail_to ):
  
  formatOutPut("INFO","Attempting to Start " +server_name+" on "+node_name+ ". NOTE: This may take several minutes.")

  serverMBean = AdminControl.completeObjectName("type=Server,process="+server_name+",node="+node_name+",*")

  if len(serverMBean) != 0:
   formatOutPut("INFO",server_name+" on "+node_name+ " is already started")
   return 0

  
  try:
   # Start the server with a 30 second wait time
   AdminControl.startServer(server_name , node_name, 10 )

  except:
   formatOutPut("WARNING", "Start Failed on " +server_name+" on "+node_name)
   subject = "ALERT :  DAILY RECYCLE :  Start Failed on " +server_name+" on "+node_name
   message= "Start Failed on " +server_name+" on "+node_name+".   Please check on the server. The recycle process will continue to advance to the next server."
   SendAlert( mailserver, subject , mail_from, mail_to, message)


  return 0

#
# CheckServerStart node_name, server_name
#
def CheckServerStart( node_name, server_name ):

  start_flag = 0

  serverMBean = AdminControl.completeObjectName("type=Server,process="+server_name+",node="+node_name+",*")

  if len(serverMBean) == 0:
   state="STOPPED"
   start_flag=1

  else:
   state=AdminControl.getAttribute(serverMBean,'state')

  formatOutPut("INFO","Server "+server_name+" on node "+node_name+" is currently "+state)

  return start_flag

#
# CheckServerStop node_name, server_name
#
def CheckServerStop( node_name, server_name ):

  stop_flag = 0

  serverMBean = AdminControl.completeObjectName("type=Server,process="+server_name+",node="+node_name+",*")

  if len(serverMBean) == 0:
   state="STOPPED"
   stop_flag=0

  else:
  # state=AdminControl.getAttribute(serverMBean,'state')
   state="STOPPING"
   stop_flag=1

  formatOutPut("INFO","Server "+server_name+" on node "+node_name+" is currently "+state)

  return stop_flag

#
#  StopThreadedClusterMembersOnNode
#
def StopThreadedClusterMembersOnNode( cluster_name , node_name ):

  cluster_ID=AdminConfig.getid("/ServerCluster:"+cluster_name+"/")

  cluster_member_list= AdminConfig.list("ClusterMember", cluster_ID).split("\n")

  formatOutPut("INFO","Calling multithreaded stop of all servers on "+node_name+" cluster "+cluster_name)

  for cluster_member in cluster_member_list:

   cluster_node = AdminConfig.showAttribute(cluster_member,'nodeName')
   server_name  = AdminConfig.showAttribute(cluster_member,'memberName')

   if cluster_node == node_name :

    formatOutPut("INFO", "iniating thread to stop "+server_name+" on "+node_name)

    thread.start_new_thread(StopServer,(node_name,server_name,))

    time.sleep(10)

  return 0

#
#  StopClusterMembersOnNode
#
def StopClusterMembersOnNode( cluster_name , node_name ):

  cluster_ID=AdminConfig.getid("/ServerCluster:"+cluster_name+"/")

  cluster_member_list= AdminConfig.list("ClusterMember", cluster_ID).split("\n")

  formatOutPut("INFO","Calling stop of all servers on "+node_name+" cluster "+cluster_name)

  for cluster_member in cluster_member_list:

   cluster_node = AdminConfig.showAttribute(cluster_member,'nodeName')
   server_name  = AdminConfig.showAttribute(cluster_member,'memberName')

   if cluster_node == node_name :

    formatOutPut("INFO", "iniating stop of "+server_name+" on "+node_name)

    StopServer(node_name,server_name)

    time.sleep(10)

  return 0


#
# StartClusterMembersOnNode
#

def StartClusterMembersOnNode( cluster_name , node_name, mail_from, mail_to ):
 
  formatOutPut("INFO", "Starting servers for cluster "+cluster_name+ " on node "+node_name)

  cluster_ID=AdminConfig.getid("/ServerCluster:"+cluster_name+"/")

  cluster_member_list= AdminConfig.list("ClusterMember", cluster_ID).split("\n")

  for cluster_member in cluster_member_list:

    cluster_node = AdminConfig.showAttribute(cluster_member,'nodeName')
    server_name  = AdminConfig.showAttribute(cluster_member,'memberName')

    if cluster_node == node_name :

      formatOutPut("INFO", "Attempting to Start " +server_name+" on "+cluster_node+ ". NOTE: This may take several minutes.")
          
      try:
       # Start the server with a 30 second wait time
       AdminControl.startServer(server_name , node_name, 10 )

      except:
        formatOutPut("WARNING", "Start Failed on " +server_name+" on "+cluster_node)
        subject = "ALERT :  DAILY RECYCLE :  Start Failed on " +server_name+" on "+cluster_node
        message= "Start Failed on " +server_name+" on "+cluster_node+".   Please check on the server. The recycle process will continue to advance to the next server."
        SendAlert( mailserver, subject , mail_from, mail_to, message)

  return 0

######################################################################
#
#  Function:  startCluster
#  Purpose :  Start a Cluster
#
######################################################################
def startCluster(cell,cluster_name):

        #cluster_ID=AdminConfig.getid("/ServerCluster:"+cluster_name+"/")

        cluster_ID = AdminControl.completeObjectName("cell="+cell+",type=Cluster,name="+cluster_name+",*")

        formatOutPut("INFO","attempting to start cluster "+cluster_name)

        try:
         AdminControl.invoke(cluster_ID, 'start')
        except:
         except_string1 = sys.exc_type
         except_string2 = sys.exc_value
         timestamp = strftime("%Y-%m-%d %H:%M:%S")
         print timestamp," : FATAL : ",except_string1,except_string2

         formatOutPut( "ERROR", "wsadmin will now exit with return code 1" )
         # Exit with error code 1.  The calling script should handle the return code gracefully
         sys.exit(1)


        complete=1
        while complete == 1:
         state=AdminControl.getAttribute(cluster_ID, 'state')
         formatOutPut("INFO","cluster "+cluster_name+" is at state "+state)

         if state == "websphere.cluster.running":
          break
         time.sleep(30)

        formatOutPut("INFO","cluster "+cluster_name+" started")


######################################################################
#
#  Function:  stopCluster
#  Purpose :  Stop a Cluster
#
######################################################################
def stopCluster(cell,cluster_name):

        #cluster_ID=AdminConfig.getid("/ServerCluster:"+cluster_name+"/")

        cluster_ID = AdminControl.completeObjectName("cell="+cell+",type=Cluster,name="+cluster_name+",*")

        formatOutPut("INFO","attempting to stop cluster "+cluster_name)

        try:
         AdminControl.invoke(cluster_ID, 'stop')
        except:
         except_string1 = sys.exc_type
         except_string2 = sys.exc_value
         timestamp = strftime("%Y-%m-%d %H:%M:%S")
         print timestamp," : FATAL : ",except_string1,except_string2

         formatOutPut( "ERROR", "wsadmin will now exit with return code 1" )

         # Exit with error code 1.  The calling script should handle the return code gracefully
         sys.exit(1)

        complete=1
        while complete == 1:
         state=AdminControl.getAttribute(cluster_ID, 'state')
         formatOutPut("INFO","Cluster "+cluster_name+" is at state "+state)

         if state == "websphere.cluster.stopped":
          break
         time.sleep(30)

        formatOutPut("INFO","cluster "+cluster_name+" stopped")



######################################################################
#
#  Function:  getClusterState
#  Purpose :  Get the state of a cluster
#
######################################################################


def getClusterState(cell, cluster_name):

        cluster_ID = AdminControl.completeObjectName("cell="+cell+",type=Cluster,name="+cluster_name+",*")

        state=AdminControl.getAttribute(cluster_ID, 'state')
        formatOutPut("INFO","cluster "+cluster_name+" is at state "+state)

######################################################################
#
#  Function:  updateCluster
#  Purpose :  deploy to a Cluster as an update.  You must synch the node seperately
#
######################################################################

def updateCluster(cell, cluster_name, ear , app_name, vhost, war, module ):

        formatOutPut("INFO","Updating " + cluster_name + " with " + ear + ". Mapping to " +vhost)


        try:
         AdminApp.install( ear , "[ -cluster "+cluster_name+" -appname "+app_name+" -update -cell "+cell+" -MapWebModToVH [[ '"+module+"' "+war+",WEB-INF/web.xml "+vhost+"]]   ]")
#         AdminApp.install( ear , "[ -cluster "+cluster_name+" -appname "+app_name+" -update -update.ignore.new ]")
        except:
         except_string1 = sys.exc_type
         except_string2 = sys.exc_value
         timestamp = strftime("%Y-%m-%d %H:%M:%S")
         print timestamp," : FATAL : ",except_string1,except_string2

         formatOutPut( "ERROR", "wsadmin will now exit with return code 1" )
         # Exit with error code 1.  The calling script should handle the return code gracefully
         sys.exit(1)

        complete = AdminApp.isAppReady(app_name)
        formatOutPut("INFO","Application update status is : "+complete)

        while complete != "true":
         formatOutPut("INFO","Application update status is "+complete+". Waiting 30 seconds to try again")
         time.sleep(30)
         complete = AdminApp.isAppReady(app_name)

        formatOutPut("INFO",app_name+" is now updated and ready to synchronize nodes and start")

        AdminConfig.save()

######################################################################
#
#  Function:  updateClusterPartialApp
#  Purpose :  deploy to a Cluster as an update.  You must synch the node seperately
#
######################################################################

def updateClusterPartialApp( cluster_name, ear , app_name ):

        formatOutPut("INFO","Updating " + cluster_name + " with " + ear)

        try:
         AdminApp.update(app_name, 'partialapp', "[-contents "+ear+" ]")
        except:
         except_string1 = sys.exc_type
         except_string2 = sys.exc_value
         timestamp = strftime("%Y-%m-%d %H:%M:%S")
         print timestamp," : FATAL : ",except_string1,except_string2

         formatOutPut( "ERROR", "wsadmin will now exit with return code 1" )
         # Exit with error code 1.  The calling script should handle the return code gracefully
         sys.exit(1)

        complete = AdminApp.isAppReady(app_name)
        formatOutPut("INFO","Application update status is : "+complete)

        while complete != "true":
         formatOutPut("INFO","Application update status is "+complete+". Waiting 30 seconds to try again")
         time.sleep(30)
         complete = AdminApp.isAppReady(app_name)

        formatOutPut("INFO",app_name+" is now updated and ready to synchronize nodes and start")

        AdminConfig.save()

#######################################################################
#
# Function : SynchNodesCell
# Purpose  : Synchronizes all nodes in a cell
#
#######################################################################

def SynchNodesCell():
        syncMBean = AdminControl.queryNames('type=NodeSync,*')

        node_list = syncMBean.split("\n")

        for nodeSync in node_list:
          formatOutPut("INFO","Synchronizing : "+nodeSync)
          AdminControl.invoke( nodeSync, 'sync')


######################################################################
#
#  Function:  displayClusterStatus
#  Purpose :  Display the status of the cluster and all members
#
######################################################################

def displayClusterStatus(cell_name,cluster_name):

        cluster_ID=AdminConfig.getid("/ServerCluster:"+cluster_name+"/")

        cluster_member_list= AdminConfig.list("ClusterMember", cluster_ID).split("\n")

        formatOutPut("INFO","Status of Cluster : "+cluster_name)
        for cluster_member in cluster_member_list:
         server = AdminControl.completeObjectName('cell='+cell+',node='+mynode+', name='+cluster_member+',type=Server,*')

         server_name  = AdminConfig.showAttribute(cluster_member,'memberName')
         state = AdminControl.getAttribute('macys-faceted_stress_c01_s52p28_m01', 'state')

         formatOutPut("INFO","ClusterMember : "+cluster_member+" is "+state)

######################################################################
#
#  Function:  generatePlugin
#  Purpose :  Generates a plugin
#
######################################################################

def generatePlugin(config_root,cell,node,webserver):

        # setup a string to use with Admincontrol.invoke
        string = config_root+" "+cell+" "+node+" "+webserver+" true"

        # Set generator to plugin
        generator = AdminControl.completeObjectName('type=PluginCfgGenerator,*')
        AdminControl.invoke(generator,'generate',string)

######################################################################
#
#  Function:  propagatePlugin
#  Purpose :  Propagates a plugin to the webservers
#
######################################################################

def propagatePlugin(config_root,cell,node,webserver):

        # setup a string to use with Admincontrol.invoke
        string = config_root+" "+cell+" "+node+" "+webserver

        # Set generator to plugin
        generator = AdminControl.completeObjectName('type=PluginCfgGenerator,*')
        try:
         AdminControl.invoke(generator,'propagate',string)
        except:
         import sys
         except_string1 = sys.exc_type
         except_string2 = sys.exc_value
         timestamp = strftime("%Y-%m-%d %H:%M:%S")
         print timestamp," : FATAL : ",except_string1,except_string2

         # Exit with error code 1.  The calling script should handle the return code gracefully
         sys.exit(1)

        formatOutPut("INFO", "Propagating plugin to "+webserver+" on node "+node)

######################################################################
#
#  Function:  disableNodePlugin
#  Purpose :  Quiesnces ( Disables ) a node in the plugin.  The plugin
#               must then be generated and propagated vi the other functions.
#
######################################################################

def disableNodePlugin(node_name,cluster_name):

        cluster_ID=AdminConfig.getid("/ServerCluster:"+cluster_name+"/")

        cluster_member_list= AdminConfig.list("ClusterMember", cluster_ID).split("\n")

        for cluster_member in cluster_member_list:

         cluster_node = AdminConfig.showAttribute(cluster_member,'nodeName')

         if cluster_node == node_name :
          try:
           AdminConfig.modify(cluster_member,[['weight','0']])
          except:

           except_string1 = sys.exc_type
           except_string2 = sys.exc_value
           timestamp = strftime("%Y-%m-%d %H:%M:%S")
           print timestamp," : FATAL : ",except_string1,except_string2

           formatOutPut( "ERROR", "wsadmin will now exit with return code 1" )
           # Exit with error code 1.  The calling script should handle the return code gracefully
           sys.exit(1)

          formatOutPut("INFO","Disabling "+cluster_member+" on "+cluster_node)

######################################################################
#
#  Function:  disableAppServerPlugin
#  Purpose :  Quiesnces ( Disables ) an application server in the plugin.  The plugin
#               must then be generated and propagated via the other functions.
#
######################################################################

def disableAppServerPlugin(node_name,server_name):

  serverMBean = AdminControl.completeObjectName("type=Server,process="+server_name+",node="+node_name+",*")

  if len(serverMBean) == 0:
   formatOutPut("INFO",server_name+" on "+node_name+ " does not exist or is it is stopped")
   return 0

  try:
    AdminConfig.modify(serverMBean,[['weight','0']])
  except:

    except_string1 = sys.exc_type
    except_string2 = sys.exc_value
    timestamp = strftime("%Y-%m-%d %H:%M:%S")
    print timestamp," : FATAL : ",except_string1,except_string2

    formatOutPut( "ERROR", "wsadmin will now exit with return code 1" )
    # Exit with error code 1.  The calling script should handle the return code gracefully
    sys.exit(1)

  formatOutPut("INFO","Disabling "+server_name+" on "+node_name)



######################################################################
#
#  Function:  enableNodePlugin
#  Purpose :  Enables a node in the plugin.  The plugin
#               must then be generated and propagated vi the other functions.
#
######################################################################

def enableNodePlugin(node_name,cluster_name):

        cluster_ID=AdminConfig.getid("/ServerCluster:"+cluster_name+"/")

        cluster_member_list= AdminConfig.list("ClusterMember", cluster_ID).split("\n")

        for cluster_member in cluster_member_list:

         cluster_node = AdminConfig.showAttribute(cluster_member,'nodeName')

         if cluster_node == node_name :
          try:
           AdminConfig.modify(cluster_member,[['weight','2']])
          except:

           except_string1 = sys.exc_type
           except_string2 = sys.exc_value
           timestamp = strftime("%Y-%m-%d %H:%M:%S")
           print timestamp," : FATAL : ",except_string1,except_string2

           formatOutPut( "ERROR", "wsadmin will now exit with return code 1" )
           # Exit with error code 1.  The calling script should handle the return code gracefully
           sys.exit(1)

          formatOutPut("INFO","Enabling "+cluster_member+" on "+cluster_node)


#####################################################################
#
#  Function:  SyncNode
#  Purpose :  Synchronizes the nodes
#
######################################################################

def syncNode(node_name):
        syncMBean = AdminControl.completeObjectName('type=NodeSync,node='+node_name+',*')

        if len(syncMBean) == 0:
         formatOutPut( "ERROR", "Could not retrive MBean for"+node_name) 
	 formatOutPut( "FATAL", "wsadmin will now exit with return code 1.  Manual intervention is required" )
         # Exit with error code 1.  The calling script should handle the return code gracefully
         sys.exit(1)

        formatOutPut("INFO", "Synchronization of node "+node_name+" started")
       
	counter = 0

        try:
         AdminControl.invoke(syncMBean, 'sync')
        except:
         except_string1 = sys.exc_type
         except_string2 = sys.exc_value
         timestamp = strftime("%Y-%m-%d %H:%M:%S")
 
         if counter == 4:
          print timestamp," : FATAL : ",except_string1,except_string2
          formatOutPut( "ERROR", "wsadmin will now exit with return code 1.  Manual intervention is required" )
          # Exit with error code 1.  The calling script should handle the return code gracefully
          sys.exit(1)
         else:
          print timestamp," : WARNING : ",except_string1,except_string2
          formatOutPut("INFO", "Synchronization on "+node_name+" will be attempted again in 30 seconds")
          counter = counter + 1
          time.sleep(30)

        formatOutPut("INFO", "Synchronization of node "+node_name+" complete")


#####################################################################
#
#  Function:  SyncNodesInCluster
#  Purpose :  Synchronizes the nodes in a cluster
#
######################################################################

def synchNodesInCluster(cell,cluster):

        cluster_ID=AdminConfig.getid("/ServerCluster:"+cluster_name+"/")

        cluster_node_list= AdminConfig.list("nodeName", cluster_ID).split("\n")

        for cluster_member in cluster_node_list:

         cluster_node = AdminConfig.showAttribute(cluster_member,'nodeName')

        syncMBean = AdminControl.completeObjectName('type=NodeSync,node='+node_name+',*')

        try:
         AdminControl.invoke(syncMBean, 'sync')
        except:

         except_string1 = sys.exc_type
         except_string2 = sys.exc_value
         timestamp = strftime("%Y-%m-%d %H:%M:%S")
         print timestamp," : FATAL : ",except_string1,except_string2

         formatOutPut( "ERROR", "wsadmin will now exit with return code 1" )
         # Exit with error code 1.  The calling script should handle the return code gracefully
         sys.exit(1)


        formatOutPut("INFO", "Synchronizing node : "+node_name)


######################################################################
#
# GetNodesforCluster :  returns a list of nodes in a cluster
#
######################################################################

def GetNodesforCluster( cluster_name ):

  formatOutPut("INFO", "Retrieving nodes for "+cluster_name)

  cluster_ID=AdminConfig.getid("/ServerCluster:"+cluster_name+"/")
  
  #create a list
  node_list = []

  cluster_member_list= AdminConfig.list("ClusterMember", cluster_ID).split("\n")

  for cluster_member in cluster_member_list:

    cluster_node = AdminConfig.showAttribute(cluster_member,'nodeName')

    node_list.append(cluster_node)

  return node_list

######################################################################
#
# uniqueList :  Takes a list and removes duplicates to return a unique list.  
#
######################################################################


def uniqueList(seq): 
   # order preserving 
    checked = [] 
    for e in seq: 
        if e not in checked: 
            checked.append(e) 
    return checked


######################################################################
#
#  Function:  updateApplication
#  Purpose :  deploy to an Application as an update.  You must synch the node seperately
#
######################################################################

def updateApplication(cell, node_name, ear , app_name, vhost, war1, module1, war2, module2, war3, module3, war4, module4, war5, module5, war6, module6 ):

#        formatOutPut("INFO","Updating " + app_name + " on " + node_name + " with " + ear +" and module= " + module + " vhost= " +vhost+ " war= " +war)

        try:
         AdminApp.install( ear , "[ -node "+node_name+" -appname "+app_name+ " -update -cell "+cell+" -MapWebModToVH [[ '"+module1+"' "+war1+",WEB-INF/web.xml "+vhost+"][ '"+module2+"' "+war2+",WEB-INF/web.xml "+vhost+"][ '"+module3+"' "+war3+",WEB-INF/web.xml "+vhost+"][ '"+module4+"' "+war4+",WEB-INF/web.xml "+vhost+"][ '"+module5+"' "+war5+",WEB-INF/web.xml "+vhost+"][ '"+module6+"' "+war6+",WEB-INF/web.xml "+vhost+"]]   ]")
 
#         AdminApp.install( ear , "[ -node "+node_name+" -appname "+app_name+ " -update -cell "+cell+" -MapWebModToVH [[ 'module' "+war+",WEB-INF/web.xml "+vhost+"]]   ]")
#         AdminApp.install( ear , "[ -cell " +cell+ " -node " +node_name+ " -appname "+app_name+" -update -update.ignore.new ]")
        except:
         except_string1 = sys.exc_type
         except_string2 = sys.exc_value
         timestamp = strftime("%Y-%m-%d %H:%M:%S")
         print timestamp," : FATAL : ",except_string1,except_string2

         formatOutPut( "ERROR", "wsadmin will now exit with return code 1" )
         # Exit with error code 1.  The calling script should handle the return code gracefully
         sys.exit(1)

        complete = AdminApp.isAppReady(app_name)
        formatOutPut("INFO","Application update status is : "+complete)

        while complete != "true":
         formatOutPut("INFO","Application update status is "+complete+". Waiting 30 seconds to try again")
         time.sleep(30)
         complete = AdminApp.isAppReady(app_name)

        formatOutPut("INFO",app_name+" is now updated and ready to synchronize nodes and start")

        AdminConfig.save()

######################################################################
#
#  Function:  updateBloomMidtier_old
#  Purpose :  deploy to an Application as an update.  You must synch the node seperately
#
######################################################################

def updateBloomMidtier_old(cell, node_name, ear , app_name, vhost, war1, module1, war2, module2, war3, module3): 

        formatOutPut("INFO","Updating " + app_name + " on " + node_name + " with ear=" + ear +", vhost=" +vhost+ ", module1= " +module1+ ", war1= " +war1+ ", module2=" +module2+ ", war2= " +war2)

        try:
         AdminApp.install( ear , "[ -node "+node_name+" -appname "+app_name+ " -update -cell "+cell+" -MapWebModToVH [[ '"+module1+"' "+war1+",WEB-INF/web.xml "+vhost+"][ '"+module2+"' "+war2+",WEB-INF/web.xml "+vhost+"][ '"+module3+"' "+war3+",WEB-INF/web.xml "+vhost+"]]   ]")
 
        except:
         except_string1 = sys.exc_type
         except_string2 = sys.exc_value
         timestamp = strftime("%Y-%m-%d %H:%M:%S")
         print timestamp," : FATAL : ",except_string1,except_string2

         formatOutPut( "ERROR", "wsadmin will now exit with return code 1" )
         # Exit with error code 1.  The calling script should handle the return code gracefully
         sys.exit(1)

        complete = AdminApp.isAppReady(app_name)
        formatOutPut("INFO","Application update status is : "+complete)

        while complete != "true":
         formatOutPut("INFO","Application update status is "+complete+". Waiting 30 seconds to try again")
         time.sleep(30)
         complete = AdminApp.isAppReady(app_name)

        formatOutPut("INFO",app_name+" is now updated and ready to synchronize nodes and start")

        AdminConfig.save()


######################################################################
#
#  Function:  updateBloomMidtier
#  Purpose :  deploy to an Application as an update.  You must synch the node seperately
#
######################################################################

def updateBloomMidtier(cell, node_name, ear , app_name, vhost, web_node1, web_server1): 

        formatOutPut("INFO","Updating " + app_name + " on " + node_name + " with " + ear +" and vhost= " +vhost+ " web server=  " + web_server1)

        try:
 
         AdminApp.install( ear, "[ -node "+node_name+" -appname "+app_name+" -update -cell "+cell+" -MapWebModToVH [[ .*  .*  "+vhost+"]] -MapModulesToServers [[ .* .* +WebSphere:cell="+cell+",node="+web_node1+",server="+web_server1+"]] ]")
        except:
         except_string1 = sys.exc_type
         except_string2 = sys.exc_value
         timestamp = strftime("%Y-%m-%d %H:%M:%S")
         print timestamp," : FATAL : ",except_string1,except_string2

         formatOutPut( "ERROR", "wsadmin will now exit with return code 1" )
         # Exit with error code 1.  The calling script should handle the return code gracefully
         sys.exit(1)

        complete = AdminApp.isAppReady(app_name)
        formatOutPut("INFO","Application update status is : "+complete)

        while complete != "true":
         formatOutPut("INFO","Application update status is "+complete+". Waiting 30 seconds to try again")
         time.sleep(30)
         complete = AdminApp.isAppReady(app_name)

        formatOutPut("INFO",app_name+" is now updated and ready to synchronize nodes and start")

        AdminConfig.save()


######################################################################
#
#  Function:  SendAlert
#  Purpose :  Send zlert email
#
######################################################################

def SendAlert( mailserver, subject , from_sender , to_list, message):

	import smtplib

 	SUBJECT = subject

 	FROM = from_sender
 	TO  = to_list

 	TEXT = message

 	# Prepare actual message

 	message = """\
 	From: %s
 	To: %s
 	
	Subject: %s
	
 	%s
	""" % (FROM, ", ".join(TO), SUBJECT, TEXT)

 	# Establish an SMTP object and connect to your mail server
 	server = smtplib.SMTP(mailserver)
 	server.sendmail(FROM, TO, message)
 	server.close()



######################################################################
#
#  Function:  updateMacysMidtier
#  Purpose :  deploy to an Application as an update.  You must synch the node seperately
#
######################################################################

def updateMacysMidtier(cell, node_name, ear , app_name, vhost, web_node1, web_server1):

        formatOutPut("INFO","Updating " + app_name + " on " + node_name + " with " + ear +" and vhost= " +vhost+ " web server= "+web_server1)

        try:
         AdminApp.install( ear, "[ -node "+node_name+" -appname "+app_name+" -update -cell "+cell+" -MapWebModToVH [[ .*  .*  "+vhost+"]] -MapModulesToServers [[ .* .* +WebSphere:cell="+cell+",node="+web_node1+",server="+web_server1+"]] ]")

#         AdminApp.install( ear , "[ -node "+node_name+" -appname "+app_name+ " -update -cell "+cell+" -MapWebModToVH [[ '"+module1+"' "+war1+",WEB-INF/web.xml "+vhost+"][ '"+module2+"' "+war2+",WEB-INF/web.xml "+vhost+"][ '"+module3+"' "+war3+",WEB-INF/web.xml "+vhost+"][ '"+module4+"' "+war4+",WEB-INF/web.xml "+vhost+"][ '"+module5+"' "+war5+",WEB-INF/web.xml "+vhost+"][ '"+module6+"' "+war6+",WEB-INF/web.xml "+vhost+"][ '"+module7+"' "+war7+",WEB-INF/web.xml "+vhost+"]]   ]")
 
        except:
         except_string1 = sys.exc_type
         except_string2 = sys.exc_value
         timestamp = strftime("%Y-%m-%d %H:%M:%S")
         print timestamp," : FATAL : ",except_string1,except_string2

         formatOutPut( "ERROR", "wsadmin will now exit with return code 1" )
         # Exit with error code 1.  The calling script should handle the return code gracefully
         sys.exit(1)

        complete = AdminApp.isAppReady(app_name)
        formatOutPut("INFO","Application update status is : "+complete)

        while complete != "true":
         formatOutPut("INFO","Application update status is "+complete+". Waiting 30 seconds to try again")
         time.sleep(30)
         complete = AdminApp.isAppReady(app_name)

        formatOutPut("INFO",app_name+" is now updated and ready to synchronize nodes and start")

        AdminConfig.save()


######################################################################
#
#  Function:  updateApplicationStress
#  Purpose :  deploy to an Application as an update.  You must synch the node seperately
#
######################################################################

def updateApplicationStress(cell, node_name, ear , app_name, vhost, web_node1, web_server1, web_node2, web_server2 ):

        formatOutPut("INFO","Updating " + app_name + " on " + node_name + " with " + ear +" and vhost= " +vhost+ " web_server= "+web_server1+" and "+web_server2)

        try:
         AdminApp.install( ear, "[ -node "+node_name+" -appname "+app_name+" -update -cell "+cell+" -MapWebModToVH [[ .*  .*  "+vhost+"]]  -MapModulesToServers [[ .* .* +WebSphere:cell="+cell+",node="+web_node1+",server="+web_server1+"+WebSphere:cell="+cell+",node="+web_node2+",server="+web_server2+"]]  ]")

#         AdminApp.install( ear, "[ -node "+node_name+" -appname "+app_name+" -update -cell "+cell+" -MapWebModToVH [[ .*  .*  "+vhost+"]]  ]")
 
#         AdminApp.install( ear , "[ -node "+node_name+" -appname "+app_name+ " -update -cell "+cell+" -MapWebModToVH [[ 'module' "+war+",WEB-INF/web.xml "+vhost+"]]   ]")
#         AdminApp.install( ear , "[ -cell " +cell+ " -node " +node_name+ " -appname "+app_name+" -update -update.ignore.new ]")
        except:
         except_string1 = sys.exc_type
         except_string2 = sys.exc_value
         timestamp = strftime("%Y-%m-%d %H:%M:%S")
         print timestamp," : FATAL : ",except_string1,except_string2

         formatOutPut( "ERROR", "wsadmin will now exit with return code 1" )
         # Exit with error code 1.  The calling script should handle the return code gracefully
         sys.exit(1)

        complete = AdminApp.isAppReady(app_name)
        formatOutPut("INFO","Application update status is : "+complete)

        while complete != "true":
         formatOutPut("INFO","Application update status is "+complete+". Waiting 30 seconds to try again")
         time.sleep(30)
         complete = AdminApp.isAppReady(app_name)

        formatOutPut("INFO",app_name+" is now updated and ready to synchronize nodes and start")

        AdminConfig.save()


#
#  testshellcommand
#
def testshellcommand ():

    import os
    import sys

    formatOutPut("INFO","Calling testshellcommand" )

    cmd = "ls -l"
    rc = os.system(cmd)
    if rc == 0:
        print "Successful"
    else:
        print "Failed: return code=%i..." % rc
    # read and process the .err file...

    return 0

