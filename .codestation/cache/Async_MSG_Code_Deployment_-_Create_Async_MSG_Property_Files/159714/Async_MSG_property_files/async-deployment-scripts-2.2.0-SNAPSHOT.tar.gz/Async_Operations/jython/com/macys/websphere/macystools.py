import java.lang , time
# Import thread package for using multiple threads
import thread
import sys
from time import strftime
from java.sql import * 
from java.lang import *
# Import log4j
from org.apache.log4j import * 
import com.mst.websphere.buildtools


# import the wsadmin objects below.
# The functions in ths library can be invoked either by script or wsadmin command line
# to invoke from wsadmin use the profile to import the profileinit.py script and then call the package and function.
# -profile "<path_to_profile/profileinit.py" -c "com.mst.websphere.admintools.updateCluster()"

try:
  import AdminConfig
  import AdminControl
  import AdminApp
  import AdminTask
  import Help
except:
        pass

logger = Logger.getLogger(__name__); 

def preloadCacheCluster(cache_cluster_id, stmt):
	
	logger.info( "resetting preload complete entry for cache cluster id "+str(cache_cluster_id) )
	sql =  "update cache_cluster set PRELOAD_COMPLETE=null where CACHE_CLUSTER_ID="+str(cache_cluster_id)
	stmt.executeUpdate(sql)

	
	query = "FDS:name=cachePreloader,*"
	
	try:
		preloader = AdminControl.queryNames ( query )
	except:
		logger.fatal("Did not find preloader mbean")

	try:
		AdminControl.invoke ( preloader , 'startPreload' )
	except:
		sys.exit(1)
		
	logger.info("Preload Started")

def CheckPreloadCompletedID( cache_cluster_id , stmt ):

   complete = 1
   preload_complete = ''
   while complete == 1 :
		
	sql = "select PRELOAD_COMPLETE from cache_cluster where CACHE_CLUSTER_ID="+str(cache_cluster_id)+" and PRELOAD_COMPLETE IS NOT NULL"
	rs = stmt.executeQuery(sql)
  
 	while (rs.next()):
		preload_complete = rs.getString('PRELOAD_COMPLETE')
  	rs.close 
  	
  	if preload_complete == '':
  	   logger.info ("Preload still in progress")
  	   time.sleep(30)
  	else:
  	   logger.info("Preload Complete")
 	   return 0
	
def GetPreloadServerHostNameFromCacheID( cache_cluster_id, stmt ):
	sql = "select JMX_HOST from host_cache_cluster where SERVER_NAME in ( select ATTR_VALUE from UNARY_CACHE_CLUSTER_ATTR_VAL where CACHE_CLUSTER_ID="+str(cache_cluster_id)+" AND ATTR_NAME='PRELOADING_CLONE_NAME')"
	rs = stmt.executeQuery(sql)
  
 	while (rs.next()):
		jmx_host = rs.getString('JMX_HOST')
  	rs.close  
	
	return jmx_host
	
def GetPreloadServerPortFromCacheID( cache_cluster_id, stmt ):
	sql = "select JMX_PORT from host_cache_cluster where SERVER_NAME in ( select ATTR_VALUE from UNARY_CACHE_CLUSTER_ATTR_VAL where CACHE_CLUSTER_ID="+str(cache_cluster_id)+" AND ATTR_NAME='PRELOADING_CLONE_NAME')"
	rs = stmt.executeQuery(sql)
  
 	while (rs.next()):
		jmx_port = rs.getString('JMX_PORT')
  	rs.close  
	
	return  jmx_port

	
def preloadCacheClusterClient(cache_cluster_id, preload_server, preload_port, properties, stmt):

	#  Add logic to null database entry
	
	"""
	sql =  "update cache_cluster set PRELOAD_COMPLETE=null where CACHE_CLUSTER_ID="+cache_cluster_id
	stmt.executeUpdate(sql)

	connectProps = java.util.Properties()
	connectProps.setProperty(com.ibm.websphere.management.AdminClient.CONNECTOR_TYPE, com.ibm.websphere.management.AdminClient.CONNECTOR_TYPE_SOAP)
	connectProps.setProperty(com.ibm.websphere.management.AdminClient.CONNECTOR_HOST, preload_server )
	connectProps.setProperty(com.ibm.websphere.management.AdminClient.CONNECTOR_PORT, preload_port )
	props.setProperty(com.ibm.websphere.management.AdminClient.CONNECTOR_SECURITY_ENABLED, "true");
   	props.setProperty(com.ibm.websphere.management.AdminClient.USERNAME, properties.getProperty(' '));
   	props.setProperty(com.ibm.websphere.management.AdminClient.PASSWORD, "user24test");
   	props.setProperty(com.ibm.websphere.management.AdminClient.CACHE_DISABLED, "false");
      	props.setProperty("javax.net.ssl.trustStore", "C:/WebSphere/AppServer/etc/DummyClientTrustFile.jks");
	props.setProperty("javax.net.ssl.keyStore", "C:/WebSphere/AppServer/etc/DummyClientKeyFile.jks");
	props.setProperty("javax.net.ssl.trustStorePassword", "WebAS");
	props.setProperty("javax.net.ssl.keyStorePassword", "WebAS");



	property_list = connectProps.propertyNames()
	for key in property_list:
		print key+":"+connectProps.getProperty(key)

	 try:
		adminClient = com.ibm.websphere.management.AdminClientFactory.createAdminClient(connectProps)
	 except:
		import sys
        	except_string1 = sys.exc_type
        	except_string2 = sys.exc_value
        	logger.fatal( str(except_string1))
        	logger.fatal( str(except_string2))


	query = "FDS:name=cachePreloader,*"

	queryName = javax.management.ObjectName(query)


	logger.debug( "ObjectName "+str(queryName) )

	try:
	 	result = adminClient.queryNames(queryName, None )
	except:
	 	import sys
         	except_string1 = sys.exc_type
         	except_string2 = sys.exc_value
         	logger.fatal( str(except_string1))
         	logger.fatal( str(except_string2))	

	if  result == '':
    		logger.warn("Node agent MBean was not found")
	else:
    		logger.debug("The mbean is "+str(result))
    		adminClient.invoke( queryName, 'startPreload', None, None )
    """
        
def CheckPreloadComplete(cluster_name, stmt):
	
	logger.info("Not Yet Implemented")
	#  While loop until preload is complete
	
	"""
	while true
 		sql_select = "select PRELOAD_COMPLETE from cache_cluster where CACHE_CLUSTER_ID in (${CLUSTER_ID1},${CLUSTER_ID2}) and CACHE_CLUSTER_NAME='+cluster_name+' and PRELOAD_COMPLETE IS NOT NULL"
		rs = stmt.executeQuery(sql_select)
		while (rs.next()):
			result = rs.getInt('PRELOAD_COMPLETE')
		rs.close
		
 		if result != '':
 			break

 		else
   			logger.info("Preload in progress")
 
 			time.sleep(60)

	
	logger.info("Preload in Complete")
	"""
def CreateCacheClusterDB( stmt, cluster, cache_cluster_name ):

	cell_name = AdminControl.getCell()
	logger.debug("Creating SQL for Coherence DB configuration")
	
	#
	#  Query the database for other cache clusters and see if the WebSphere Cell has other clusters associated with it.
	#
	sql_select ="select count(*) from CACHE_CLUSTER WHERE CACHE_CLUSTER_DESCR LIKE '%"+cell_name+"%'"
	rs = stmt.executeQuery(sql_select)
	while (rs.next()):
		number_of_clusters = rs.getInt(1)
	rs.close
	
	description = cell_name
	
	if number_of_clusters == 1:
	 # 1 Cache Cluster already exists for the cell.  So we will now create a cluster pair.  The new cluster will be the secondary cluster
	 
	 # Get the Cache_Cluster_ID of the the original cluster
	 sql_select ="select cache_cluster_id from CACHE_CLUSTER WHERE CACHE_CLUSTER_DESCR LIKE '%"+cell_name+"%'"
	 rs = stmt.executeQuery(sql_select)
	 while (rs.next()):
		paired_cache_cluster_id = rs.getInt(1)
	 rs.close
	
	 sql = "INSERT INTO CACHE_CLUSTER (CACHE_CLUSTER_NAME,CACHE_CLUSTER_DESCR, PAIRED_CACHE_CLUSTER_ID) VALUES ( '"+cache_cluster_name+"','"+description+"',"+str(paired_cache_cluster_id)+")"
	 logger.debug(sql)
	 stmt.executeUpdate(sql)
	
	elif number_of_clusters == 0:
	 # No cache clusters exist for the cell. We can create a primary cluster
	 sql = "INSERT INTO CACHE_CLUSTER (CACHE_CLUSTER_NAME,CACHE_CLUSTER_DESCR) VALUES ( '"+cache_cluster_name+"','"+description+"')"
	 logger.debug(sql)
	 stmt.executeUpdate(sql)
	
	
	# Get the cache cluster ID of the cluster that we just created.
	sql_select ="select CACHE_CLUSTER_ID from CACHE_CLUSTER where cache_cluster_name = '"+cache_cluster_name+"' and CACHE_CLUSTER_DESCR = '"+description+"'"
	rs = stmt.executeQuery(sql_select)
	while (rs.next()):
		cache_cluster_id = rs.getInt(1)
	rs.close
	
	
	
	# If this was the second cache cluster being created then pair the original cluster to the new cluster.
	if number_of_clusters == 1:
	 # Update the original cache cluster to be paired with the cluster that we just created.
	 sql = "UPDATE CACHE_CLUSTER SET PAIRED_CACHE_CLUSTER_ID="+str(cache_cluster_id)+" WHERE CACHE_CLUSTER_ID="+str(paired_cache_cluster_id)
	 logger.debug(sql)
	 stmt.executeUpdate(sql)
	elif number_of_clusters == 0:
	 paired_cache_cluster_id = cache_cluster_id
	 sql = "UPDATE CACHE_CLUSTER SET PAIRED_CACHE_CLUSTER_ID="+str(cache_cluster_id)+" WHERE CACHE_CLUSTER_ID="+str(paired_cache_cluster_id)
	 logger.debug(sql)
	 stmt.executeUpdate(sql) 	
	
	return str(cache_cluster_id)

def CreateCoherenceConfigDB( stmt, cluster, cache_cluster_id,cache_cluster_name, paired_cache_cluster_id,coherence_multicast_port,coherence_multicast_ip, is_primary, preloading_clone_name):

	"""
	@param stmt :  DB connection that has been created by the calling script
	
	"""	
	
	logger.debug("Creating SQL for Coherence DB configuration")

	sql = "INSERT INTO UNARY_CACHE_CLUSTER_ATTR_VAL (CACHE_CLUSTER_ID,ATTR_NAME,ATTR_VALUE) VALUES ("+cache_cluster_id+",'COHERENCE_MULTICAST_PORT','"+coherence_multicast_port+"')" 
	logger.debug(sql)
	stmt.addBatch(sql)

	sql = "INSERT INTO UNARY_CACHE_CLUSTER_ATTR_VAL (CACHE_CLUSTER_ID,ATTR_NAME,ATTR_VALUE) VALUES ("+cache_cluster_id+",'COHERENCE_MULTICAST_IP','"+coherence_multicast_ip+"')" 
	logger.debug(sql)
	stmt.addBatch(sql)

	sql = "INSERT INTO UNARY_CACHE_CLUSTER_ATTR_VAL (CACHE_CLUSTER_ID,ATTR_NAME,ATTR_VALUE) VALUES  ("+cache_cluster_id+",'IS_PRIMARY','"+is_primary+"')" 
	logger.debug(sql)
	stmt.addBatch(sql)

	sql = "INSERT INTO UNARY_CACHE_CLUSTER_ATTR_VAL (CACHE_CLUSTER_ID,ATTR_NAME,ATTR_VALUE) VALUES ("+cache_cluster_id+",'MULTICAST_ENABLED','Y')" 
	logger.debug(sql)
	stmt.addBatch(sql)

	sql = "INSERT INTO UNARY_CACHE_CLUSTER_ATTR_VAL (CACHE_CLUSTER_ID,ATTR_NAME,ATTR_VALUE) VALUES ("+cache_cluster_id+",'APP_SERVER_CLUSTER_NAME','"+cache_cluster_name+"')" 
	logger.debug(sql)
	stmt.addBatch(sql)

	sql = "INSERT INTO UNARY_CACHE_CLUSTER_ATTR_VAL (CACHE_CLUSTER_ID,ATTR_NAME,ATTR_VALUE) VALUES ("+cache_cluster_id+",'PRELOADING_CLONE_NAME','"+preloading_clone_name+"')" 
	logger.debug(sql)
	stmt.addBatch(sql)
	
	sql = "INSERT INTO UNARY_CACHE_CLUSTER_ATTR_VAL (CACHE_CLUSTER_ID,ATTR_NAME,ATTR_VALUE) VALUES ("+cache_cluster_id+",'CUSTOM_DATE_NAME','CUSTOM_DATE')"
	logger.debug(sql)
	stmt.addBatch(sql)
                                                                                                                                                                                                                                    
	sql = "INSERT INTO UNARY_CACHE_CLUSTER_ATTR_VAL (CACHE_CLUSTER_ID,ATTR_NAME,ATTR_VALUE) VALUES ("+cache_cluster_id+",'CSS_CUSTOM_DATE_NAME','CSS_CUSTOM_DATE')"
	logger.debug(sql)
	stmt.addBatch(sql)
	

def AddAppServerToCoherenceConfigDB(stmt, cache_cluster_id, member_name, node_name, unicast_port, host_name, is_cache_server, attr_val_seq_nbr):
	
        
        #cache_cluster_id = int(cache_cluster_id)
        unicast_port = str(unicast_port)
	attr_val_seq_nbr = str(attr_val_seq_nbr)
	
	logger.debug("Creating SQL for Coherence DB configuration of member :"+member_name)
	
  	if is_cache_server == 'Y':
   	 sql = "INSERT INTO HOST_CACHE_CLUSTER (CACHE_CLUSTER_ID,NODE_NAME,SERVER_NAME,UNICAST_PORT,IS_CACHE_SERVER) VALUES ("+cache_cluster_id+",'"+node_name+"','"+member_name+"',"+unicast_port+",'"+is_cache_server+"')"
    	 logger.debug(sql)
    	 stmt.addBatch(sql)
    	 sql = "INSERT INTO MULTI_CACHE_CLUSTER_ATTR_VAL (CACHE_CLUSTER_ID,ATTR_NAME,ATTR_VALUE,ATTR_VAL_SEQ_NBR) VALUES ("+cache_cluster_id+",'WELL_KNOWN_ADDRESS','"+host_name+":"+unicast_port+"',"+attr_val_seq_nbr+")"
 	 logger.debug(sql)
 	 stmt.addBatch(sql)  	
  	else :
   	 sql = "INSERT INTO HOST_CACHE_CLUSTER (CACHE_CLUSTER_ID,NODE_NAME,SERVER_NAME,IS_CACHE_SERVER) VALUES ("+cache_cluster_id+",'"+node_name+"','"+member_name+"','"+is_cache_server+"')"
	 logger.debug(sql)
	 stmt.addBatch(sql)
	 

def RemoveAppServerFromCoherenceConfigDB( stmt, cache_cluster_id, member_name, node_name, unicast_port ):
	print "Need To add stuff"

def RemoveClusterFromCoherenceConfigDB(  stmt, cache_cluster_id, node_name, member_name):
	
	sql = "DELETE FROM HOST_CACHE_CLUSTER WHERE CACHE_CLUSTER_ID="+cache_cluster_id+" AND NODE_NAME = '"+node_name+"' AND SERVER_NAME='"+member_name+"'"
	logger.debug(sql)
	stmt.executeUpdate(sql)
  
def CreateDB2Connection(db2_host, db2_port, db2_name, db2_user, db2_password, db2_lib_path, base_dir):

	import sys
	
	db2_lib_path_list = db2_lib_path[0:].split(':')
	jarLoad = com.mst.websphere.buildtools.classPath()
	
	for db2_jar in db2_lib_path_list :
		logger.debug( "Adding the following to the classpath : "+str(base_dir)+"/"+str(db2_jar))
        	a = jarLoad.addFile(str(base_dir)+"/"+str(db2_jar))
	
	# load DB2 JDBC type 2 driver
	Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance()
	logger.debug("Creating DB Connection to 'jdbc:db2://"+db2_host+":"+db2_port+"/"+db2_name+"','"+db2_user)
	
	con = DriverManager.getConnection( "jdbc:db2://"+db2_host+":"+db2_port+"/"+db2_name,db2_user,db2_password)

	con.setAutoCommit(0)
	return con
	

def GetPrimaryGridIDForCell(stmt):
  """
  	Returns the cache_cluster_id for the primary grid of a cell.
  """
  cell_name = AdminControl.getCell()
  logger.debug("Creating SQL for Coherence DB configuration")
  
  sql = "select CACHE_CLUSTER_ID from UNARY_CACHE_CLUSTER_ATTR_VAL WHERE ATTR_NAME='IS_PRIMARY' and ATTR_VALUE='Y' and CACHE_CLUSTER_ID IN ( select CACHE_CLUSTER_ID from cache_cluster where CACHE_CLUSTER_DESCR like '%"+cell_name+"%' ) " 
  rs = stmt.executeQuery(sql)

  while (rs.next()):
	cache_cluster_id = rs.getInt('CACHE_CLUSTER_ID')
  rs.close
  
  print cache_cluster_id
  sql = "select CACHE_CLUSTER_NAME from CACHE_CLUSTER WHERE  CACHE_CLUSTER_ID="+str(cache_cluster_id)
  rs = stmt.executeQuery(sql)
  
  while (rs.next()):
	cache_cluster_name = rs.getString('CACHE_CLUSTER_NAME')
  rs.close  
	
	
  logger.debug("Primary Grid is "+cache_cluster_name+" . Cluster ID is "+str(cache_cluster_id))
  return str(cache_cluster_id)

def GetPrimaryGridIDForRemoteCell(stmt,cell_name):
	
  sql = "select CACHE_CLUSTER_ID from UNARY_CACHE_CLUSTER_ATTR_VAL WHERE ATTR_NAME='IS_PRIMARY' and ATTR_VALUE='Y' and CACHE_CLUSTER_ID IN ( select CACHE_CLUSTER_ID from cache_cluster where CACHE_CLUSTER_DESCR like '%"+cell_name+"%' ) " 
  rs = stmt.executeQuery(sql)

  while (rs.next()):
	cache_cluster_id = rs.getInt('CACHE_CLUSTER_ID')
  rs.close
  
  
  return cache_cluster_id

def GetSecondaryGridIDForCell(stmt):
  """
  	Returns the cache_cluster_id for the secondary grid of a cell.
  """
  cell_name = AdminControl.getCell()
  sql = "select PAIRED_CACHE_CLUSTER_ID from Cache_cluster where CACHE_CLUSTER_ID in ( select CACHE_CLUSTER_ID from UNARY_CACHE_CLUSTER_ATTR_VAL WHERE ATTR_NAME='IS_PRIMARY' and ATTR_VALUE='Y' and CACHE_CLUSTER_ID IN ( select CACHE_CLUSTER_ID from cache_cluster where CACHE_CLUSTER_DESCR like '%"+cell_name+"%' ) )"
  rs = stmt.executeQuery(sql)

  while (rs.next()):
	cache_cluster_id = rs.getInt('PAIRED_CACHE_CLUSTER_ID')
  rs.close
  
  return cache_cluster_id
  
def GetSecondaryGridIDForRemoteCell(stmt,cell_name):
  """
  	Returns the cache_cluster_id for the secondary grid of a cell.
  """
  
  sql = "select CACHE_CLUSTER_ID from UNARY_CACHE_CLUSTER_ATTR_VAL WHERE ATTR_NAME='IS_PRIMARY' and ATTR_VALUE='N' and CACHE_CLUSTER_ID IN ( select CACHE_CLUSTER_ID from cache_cluster where CACHE_CLUSTER_DESCR like '%"+cell_name+"%' ) " 
  rs = stmt.executeQuery(sql)

  while (rs.next()):
	cache_cluster_id = rs.getInt('CACHE_CLUSTER_ID')
  rs.close
  
  return cache_cluster_id

def ConfigurePreloaderInCoherenceConfigDB( stmt, host_name, member_name, soap_port ):
   
   soap_port = int(soap_port)
   logger.debug(soap_port)
   logger.debug(host_name)
   logger.debug(member_name)
   
   sql = "UPDATE HOST_CACHE_CLUSTER SET JMX_HOST='"+host_name+"', JMX_PORT="+str(soap_port)+" WHERE SERVER_NAME='"+member_name+"'"
   logger.debug(sql)
   stmt.addBatch(sql)

def RemoveCacheClusterFromCoherenceConfigDB( stmt, project, application,  cluster_name ):
   
   cell_name = AdminControl.getCell()
   cache_cluster_id = ""
   
   # Get the cache cluster ID.
   sql = "SELECT CACHE_CLUSTER_ID from cache_cluster where CACHE_CLUSTER_DESCR like '%"+cell_name+"%'" 
   logger.debug(sql)
   rs = stmt.executeQuery(sql)
   while (rs.next()):
	cache_cluster_id = rs.getInt(1)
   rs.close
   
   if cache_cluster_id == "":
   	logger.debug("No Cache Cluster ID was found.")
   	return 0
   
  
   sql = "DELETE FROM MULTI_CACHE_CLUSTER_ATTR_VAL where CACHE_CLUSTER_ID="+str(cache_cluster_id)
   logger.debug(sql)
   stmt.execute(sql)
   
   
   sql = "DELETE FROM UNARY_CACHE_CLUSTER_ATTR_VAL where CACHE_CLUSTER_ID="+str(cache_cluster_id)
   logger.debug(sql)
   stmt.execute(sql)
   
   
   sql = "DELETE FROM host_cache_cluster where CACHE_CLUSTER_ID="+str(cache_cluster_id)
   logger.debug(sql)
   stmt.execute(sql)
   
   
   sql = "DELETE FROM cache_cluster where CACHE_CLUSTER_ID="+str(cache_cluster_id) 
   logger.debug(sql)
   stmt.execute(sql)
   
def ConfigureJNDIforApplicationLogging ( project , application, node_name, member_name, url_provider_name,server_log_root ):

	cell_name = AdminControl.getCell()
    	
    	if project == 'bloomingdales':
    		name_prefix = 'bloomies'
    	else:
    		name_prefix = 'macys'
    	
    	if application == 'midtier':
    		#name_prefix='midtier_'+name_prefix
    		jndiname_prefix='midtier/'+name_prefix
    	else:
    		jndiname_prefix=name_prefix
    		
    		
    	scope = "/Cell:"+cell_name+"/Node:"+node_name+"/Server:"+member_name+"/URLProvider:"+url_provider_name+"/"
	
	urlp_id = AdminConfig.getid(scope)
    	
    	# Configure macys logging
    	name = ['name', name_prefix+'_log_file' ]
    	jndi = ['jndiName', jndiname_prefix+'/log_file' ]
    	description = ['description', 'Used by macys.com code to configure logging']
    	spec = ['spec', 'fedcom://file/#'+server_log_root+'/'+cell_name+'_mngd/logs/'+member_name+'/'+project+'_log_file.txt' ]

	urlAttrs = [name, spec, jndi, description]
        newurl_id=AdminConfig.create('URL', urlp_id, urlAttrs)
        
        # Configure macys search logging
	name = ['name', name_prefix+'_search_log_file' ]
    	jndi = ['jndiName', jndiname_prefix+'/search_log_file' ]
    	description = ['description', 'Used by macys.com code to configure logging']
    	spec = ['spec', 'fedcom://file/#'+server_log_root+'/'+cell_name+'_mngd/logs/'+member_name+'/'+project+'_search_log.txt' ]

	urlAttrs = [name, spec, jndi, description]
	
	logger.info( "Creating JNDI entry : "+str(name) )
        newurl_id=AdminConfig.create('URL', urlp_id, urlAttrs)
        AdminConfig.save() 
        logger.info( "Created JNDI entry : "+str(name) )
        

def ApplyTaxWareJVMConfig( node_name, member_name,  taxware_home, taxware_home_jni_library ):
	
	cell_name = AdminControl.getCell()
 	scope = "/Cell:"+cell_name+"/Node:"+node_name+"/Server:"+member_name
	
	logger.debug ( "Modify "+scope+"  started")
        app_id=AdminConfig.getid(scope)
        logger.debug ( "ID for "+scope+" is "+app_id )
	#Configure Process definition and process execution
        jpm_id=AdminConfig.list('JavaProcessDef',app_id)
        logger.debug ( "JavaProcessDef is = "+jpm_id )
  	
        attr1=['environment',[[['description', 'taxware'],['name','TAX_HOME'],['required','false'],['value', taxware_home ]]]]
        attr2=['environment',[[['description', 'taxware'],['name','TAX_HOME_JNI_LIBRARY'],['required','false'],['value', taxware_home_jni_library]]]]
        attr3=['environment',[[['description', 'taxware'],['name','LD_LIBRARY_PATH'],['required','false'],['value', '${LD_LIBRARY_PATH}:${TAX_HOME_JNI_LIBRARY}']]]]
        attr4=['environment',[[['description', 'taxware'],['name','AVPIN'],['required','false'],['value', '${TAX_HOME}/indata']]]]
        attr5=['environment',[[['description', 'taxware'],['name','AVPOUT'],['required','false'],['value', '${TAX_HOME}/outdata']]]]
        attr6=['environment',[[['description', 'taxware'],['name','AVPTEMP'],['required','false'],['value', '${TAX_HOME}/temp']]]]
        attr7=['environment',[[['description', 'taxware'],['name','AVPAUDIT'],['required','false'],['value', '${TAX_HOME}/audit']]]]
        attr8=['environment',[[['description', 'taxware'],['name','STEPIN'],['required','false'],['value', '${TAX_HOME}/indata']]]]
        attr9=['environment',[[['description', 'taxware'],['name','STEPOUT'],['required','false'],['value', '${TAX_HOME}/outdata']]]]
        attr10=['environment',[[['description', 'taxware'],['name','ZIPIN'],['required','false'],['value', '${TAX_HOME}/indata']]]]
        attr11=['environment',[[['description', 'taxware'],['name','ZIPOUT'],['required','false'],['value', '${TAX_HOME}/outdata']]]]
        attr12=['environment',[[['description', 'taxware'],['name','ZIPTEMP'],['required','false'],['value', '${TAX_HOME}/temp']]]]
        attr13=['environment',[[['description', 'taxware'],['name','TOOLKITOUT'],['required','false'],['value', '$TAX_HOME/tkout']]]]
        attr14=['environment',[[['description', 'taxware'],['name','CAPI_HOME'],['required','false'],['value', '$TAX_HOME/utl']]]]
        attr15=['environment',[[['description', 'taxware'],['name','BT_SHARE'],['required','false'],['value', 'T']]]]
        
        AdminConfig.modify(jpm_id, [attr1,attr2,attr3,attr4,attr5,attr6,attr7,attr8,attr9,attr10,attr11,attr12,attr13,attr14,attr15])
 
 	AdminConfig.save()
 	


def ApplyMiscJVMConfig(node_name, member_name, lib_path):
	
	cell_name = AdminControl.getCell()
 	
 	scope = "/Cell:"+cell_name+"/Node:"+node_name+"/Server:"+member_name
	
	logger.debug ( "Modify "+scope+"  started")
        app_id=AdminConfig.getid(scope)
        logger.debug ( "ID for "+scope+" is "+app_id )
	#Configure Process definition and process execution
        jpm_id=AdminConfig.list('JavaProcessDef',app_id)
        logger.debug ( "JavaProcessDef is = "+jpm_id )
        
	attr1=['environment',[[['name','LIBPATH'],['required','false'],['value', lib_path ]]]]
	attr2=['environment',[[['name','LANG'],['required','false'],['value', 'en_US']]]]
	
	AdminConfig.modify(jpm_id, [attr1,attr2])
 
 	AdminConfig.save()
 	
def pointClusterNodetoPrimaryGrid( cluster_name , node_name ):
	
	  formatOutPut("INFO", "Pointing members of "+cluster_name+ " on node "+node_name+" to ")

  	  cluster_ID=AdminConfig.getid("/ServerCluster:"+cluster_name+"/")

  	  # Split the list using a java class to determine the OS's line seperator
  	  cluster_member_list = AdminConfig.list("ClusterMember", cluster_ID).split(java.lang.System.getProperty('line.separator'))


  	  for cluster_member in cluster_member_list:

    	       cluster_node = AdminConfig.showAttribute(cluster_member,'nodeName')
    	       server_name  = AdminConfig.showAttribute(cluster_member,'memberName')
		
    	       if cluster_node == node_name:
    		   sql = "update HOST_CACHE_CLUSTER SET CACHE_CLUSTER_ID="+cache_cluster_id+" WHERE SERVER_NAME="+member_name+" AND NODE_NAME="+node_name+")"
	 	   logger.debug(sql)
	 	   stmt.addBatch(sql)
	
def pointServertoPrimaryGrid():
	print "todo"
	
 	
def sqlExecuteBatch( stmt ):
	#
	#  All members are created.  SQL can now be executed to commit the changes to the DB.
	#
	try:
		stmt.executeBatch()
	
	except com.ibm.db2.jcc.a.qg,e:        
	
		while e:
			logger.error("SQL exception. Message : "+e.getMessage()+" : SQLSTATE: " + str(e.getSQLState())+" : Error code: " + str(e.getErrorCode()))
      			e = e.getNextException()